.. _glossary:

Glossary
========

.. glossary::
   :sorted:

   PasteDeploy
      A system for configuration of WSGI web components in declarative
      ``.ini`` format.  See http://pythonpaste.org/deploy/.

   asyncore
      A standard library module for asynchronous communications.  See
      http://docs.python.org/library/asyncore.html .
