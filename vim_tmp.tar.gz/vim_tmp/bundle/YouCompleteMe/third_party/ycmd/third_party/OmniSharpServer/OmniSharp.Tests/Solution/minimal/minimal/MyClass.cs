﻿using System;

namespace minimal
{
    public class MyClass
    {
        public MyClass ()
        {
        }
    }
}

