﻿using System;

namespace minimal
{
    // Holds a reference to MyClass. Used for "go to definition" tests
    // across files.
    public class MyClassContainer
    {
        public MyClass foo;
    }
}

