class Foo(object):
  pass

Bar
