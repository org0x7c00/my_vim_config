namespace testy {
	public class GetTypeTestCase {
		public GetTypeTestCase() {
			var str = "";
			str.EndsWith("A");
		}

                /// These docs are not shown in GetType
                private int an_int_with_docs;
	}
}
